import java.io.*;
import java.net.*;

public class SocketClientBolsa {
    public static void main(String[] args) throws Exception {
        try (Socket socket = new Socket("localhost", 12346);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            while (true) {
                System.out.print("codigo de accion bursatil: ");
                String codigoAccion = reader.readLine();
    
                out.writeObject(codigoAccion);
                int opcion;

                do {
                    System.out.print("que informacion quieres conocer (1 = ValorActual | 2 = ValorMinimo | 3 = ValorMaximo | 4 = salir)");
                    opcion = Integer.parseInt(reader.readLine());
                    out.writeObject(opcion);

                    if (opcion != 4) {
                        String respuesta = (String) in.readObject();
                        System.out.println(respuesta);
                    }
                } while (opcion != 4);
                    return;//si es un 4 sale del programa
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
