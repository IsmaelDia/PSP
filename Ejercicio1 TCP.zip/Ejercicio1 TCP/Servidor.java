import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor 
{

    public static void main(String[] args) 
    {
        int puerto=1111;
        
        try 
        {
            ServerSocket Servidor = new ServerSocket(puerto); 
            System.out.println("SERVIDOR INICIADO");
            System.out.println(" ");
            Socket cliente1= Servidor.accept();
            
            // RECIBIR DEL CLIENTE 1
            DataInputStream in = new DataInputStream(cliente1.getInputStream());
            int numeroRecibido = in.readInt();
            System.out.println("Número recibido: " + numeroRecibido);
            System.out.println(" ");
 
        //------------------------------------------------------------------------------------  
            
            // ENVIAR AL CLIENTE 2
            Socket cliente2 = Servidor.accept();
            DataOutputStream out = new DataOutputStream(cliente2.getOutputStream());
            out.writeInt(numeroRecibido);
            System.out.println("Número enviado al Cliente 2");
            
            // RECIBIR EL FACTORIAL
            DataInputStream in2 = new DataInputStream(cliente2.getInputStream());
            int factorialRecibido = in2.readInt();
            System.out.println(" ");
            System.out.println("Factorial recibido" );            
            
        //-------------------------------------------------------------------------------------
        
        DataOutputStream out1 = new DataOutputStream(cliente1.getOutputStream()); //ENVIAR EL FACTORIAL
        out1.writeInt(factorialRecibido);
        System.out.println(" ");
        System.out.println("Número enviado al Cliente 1 ");
            
            Servidor.close();
        } 
        catch (IOException excepcion) {
            excepcion.printStackTrace();
        }

    }

}
