
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente1 
{

    public static void main(String[] args) 
    {
        String host="localhost";
        int puerto=1111;
        Scanner teclado = new Scanner(System.in);
        int numero;
        
        try 
        {

            Socket Cliente1 = new Socket(host,puerto);
            System.out.println("Inserta un número:");
            numero = teclado.nextInt();
            
            // ENVIAR EL NUMERO AL SERVIDOR
            DataOutputStream out = new DataOutputStream(Cliente1.getOutputStream());
            out.writeInt(numero);
            
            //-----------------------------------------------------------------------

            //RECIBIR EL FACTORIAL CALCULADO
            
            DataInputStream in = new DataInputStream(Cliente1.getInputStream());
            int factorial = in.readInt();
            System.out.println("Factorial recibido del servidor: " + factorial);

            Cliente1.close(); 

        } 
        catch (IOException excepcion) {
            excepcion.printStackTrace();
        }     
        
        
    }
    
}