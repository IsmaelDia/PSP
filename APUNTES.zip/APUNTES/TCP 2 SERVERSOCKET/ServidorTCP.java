import java.io.*;
import java.net.*;

public class ServidorTCP {
    public static void main(String[] args) {
        int puerto1 = 6666, puerto2 = 6667;

        try (ServerSocket server1 = new ServerSocket(puerto1);
             ServerSocket server2 = new ServerSocket(puerto2)) {
            
            System.out.println("Servidor iniciado. Esperando conexiones...");

            // Conectar con Cliente 1
            Socket cliente1 = server1.accept();
            DataInputStream in1 = new DataInputStream(cliente1.getInputStream());
            int numero = in1.readInt();
            System.out.println("Número recibido de Cliente 1: " + numero);
            cliente1.close();

            // Conectar con Cliente 2
            Socket cliente2 = server2.accept();
            DataOutputStream out2 = new DataOutputStream(cliente2.getOutputStream());
            out2.writeInt(numero);
            DataInputStream in2 = new DataInputStream(cliente2.getInputStream());
            int factorial = in2.readInt();
            System.out.println("Factorial recibido de Cliente 2: " + factorial);
            cliente2.close();

            // Enviar resultado a Cliente 1
            cliente1 = server1.accept();
            DataOutputStream out1 = new DataOutputStream(cliente1.getOutputStream());
            out1.writeInt(factorial);
            System.out.println("Factorial enviado a Cliente 1.");
            cliente1.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
