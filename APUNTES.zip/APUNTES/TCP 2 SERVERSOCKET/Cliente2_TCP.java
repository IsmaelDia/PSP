import java.io.*;
import java.net.*;

public class Cliente2_TCP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 6667;

        try (Socket cliente = new Socket(host, puerto);
             DataInputStream in = new DataInputStream(cliente.getInputStream());
             DataOutputStream out = new DataOutputStream(cliente.getOutputStream())) {

            // Esperando recibir un número del Servidor
            System.out.println("[Cliente 2] Esperando recibir un número del Servidor...");
            int numero = in.readInt();
            System.out.println("[Cliente 2] Número recibido del Servidor: " + numero);

            // Calculando el factorial del número recibido
            System.out.println("[Cliente 2] Calculando el factorial de " + numero + "...");
            int factorial = calcularFactorial(numero);
            System.out.println("[Cliente 2] Factorial calculado: " + factorial);

            // Enviando el factorial calculado de vuelta al Servidor
            System.out.println("[Cliente 2] Enviando el factorial al Servidor...");
            out.writeInt(factorial);
            System.out.println("[Cliente 2] Factorial enviado correctamente.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para calcular el factorial de un número
    private static int calcularFactorial(int n) {
        int resultado = 1;
        for (int i = 2; i <= n; i++) {
            resultado *= i;
        }
        return resultado;
    }
}
