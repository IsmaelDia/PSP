import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente1_TCP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 6666;

        try (Socket cliente = new Socket(host, puerto);
             DataOutputStream out = new DataOutputStream(cliente.getOutputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Ingrese un número: ");
            int numero = scanner.nextInt();
            out.writeInt(numero);

            // Esperar el resultado del servidor
            try (Socket cliente2 = new Socket(host, puerto);
                 DataInputStream in = new DataInputStream(cliente2.getInputStream())) {
                int resultado = in.readInt();
                System.out.println("Factorial recibido: " + resultado);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
