import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TCPFacturaClient {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String Host = "localhost";
        int Puerto = 6000;
        
        System.out.println("Cliente iniciado...");
        Socket cliente = new Socket(Host, Puerto);

        Scanner scanner = new Scanner(System.in);

        // Pedir datos de la factura
        System.out.print("Número de Factura: ");
        String numeroFactura = scanner.nextLine();
        System.out.print("Fecha (dd/MM/yyyy): ");
        String fechaFactura = scanner.nextLine();
        System.out.print("Importe (€): ");
        double importe = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer
        System.out.print("Tipo IVA (IGC, ESP, EUR): ");
        String tipoIVA = scanner.nextLine();

        // Crear factura y enviarla al servidor
        Factura factura = new Factura(numeroFactura, fechaFactura, importe, tipoIVA);
        ObjectOutputStream outObjeto = new ObjectOutputStream(cliente.getOutputStream());
        outObjeto.writeObject(factura);
        outObjeto.flush();

        // Recibir la factura procesada
        ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
        Factura facturaProcesada = (Factura) inObjeto.readObject();
        System.out.println("\nFactura procesada recibida del servidor:");
        System.out.println(facturaProcesada);

        // Cerrar conexiones
        scanner.close();
        inObjeto.close();
        outObjeto.close();
        cliente.close();
    }
}
