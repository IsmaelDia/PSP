import java.io.Serializable;

public class Factura implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String numeroFactura;
    private String fechaFactura;
    private double importe;
    private String tipoIVA;
    private double iva;
    private double importeTotal;

    public Factura(String numeroFactura, String fechaFactura, double importe, String tipoIVA) {
        this.numeroFactura = numeroFactura;
        this.fechaFactura = fechaFactura;
        this.importe = importe;
        this.tipoIVA = tipoIVA;
    }

    public Factura() {}

    public void calcularIVA() {
        switch (tipoIVA) {
            case "IGC":
                this.iva = importe * 0.07;
                break;
            case "ESP":
                this.iva = importe * 0.21;
                break;
            case "EUR":
                this.iva = importe * 0.15;
                break;
            default:
                this.iva = 0;
        }
        this.importeTotal = this.importe + this.iva;
    }

    public String getNumeroFactura() { return numeroFactura; }
    public void setNumeroFactura(String numeroFactura) { this.numeroFactura = numeroFactura; }
    
    public String getFechaFactura() { return fechaFactura; }
    public void setFechaFactura(String fechaFactura) { this.fechaFactura = fechaFactura; }
    
    public double getImporte() { return importe; }
    public void setImporte(double importe) { this.importe = importe; }
    
    public String getTipoIVA() { return tipoIVA; }
    public void setTipoIVA(String tipoIVA) { this.tipoIVA = tipoIVA; }
    
    public double getIVA() { return iva; }
    public double getImporteTotal() { return importeTotal; }

    @Override
    public String toString() {
        return "Factura: " + numeroFactura + "\n" +
               "Fecha: " + fechaFactura + "\n" +
               "Importe: " + importe + "€\n" +
               "Tipo IVA: " + tipoIVA + "\n" +
               "IVA: " + iva + "€\n" +
               "Importe Total: " + importeTotal + "€";
    }
}
