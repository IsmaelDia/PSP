import java.io.*;
import java.net.*;

public class TCPFacturaServer {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        int numeroPuerto = 6000;
        ServerSocket servidor = new ServerSocket(numeroPuerto);
        System.out.println("Servidor esperando conexión...");

        Socket cliente = servidor.accept();
        System.out.println("Cliente conectado desde: " + cliente.getInetAddress());

        // Flujo de entrada para recibir objeto
        ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
        Factura factura = (Factura) inObjeto.readObject();
        //System.out.println("Factura recibida:\n" + factura);

        // Calcular IVA
        factura.calcularIVA();

        // Flujo de salida para enviar objeto modificado
        ObjectOutputStream outObjeto = new ObjectOutputStream(cliente.getOutputStream());
        outObjeto.writeObject(factura);
        outObjeto.flush();
        System.out.println("Factura con cálculos enviados:\n" + factura);

        // Cerrar conexiones
        inObjeto.close();
        outObjeto.close();
        cliente.close();
        servidor.close();
    }
}
