import java.io.*;
import java.net.*;
import java.util.Scanner;

public class UDPFacturaClient {
    public static void main(String[] args) throws IOException {
        String serverAddress = "localhost";
        int port = 6000;
        DatagramSocket socket = new DatagramSocket();
        Scanner scanner = new Scanner(System.in);

        // Pedir datos de la factura
        System.out.print("Número de Factura: ");
        String numeroFactura = scanner.nextLine();
        System.out.print("Fecha (dd/MM/yyyy): ");
        String fechaFactura = scanner.nextLine();
        System.out.print("Importe (€): ");
        double importe = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer
        System.out.print("Tipo IVA (IGC, ESP, EUR): ");
        String tipoIVA = scanner.nextLine();

        // Convertir datos a una cadena CSV
        String facturaString = numeroFactura + "," + fechaFactura + "," + importe + "," + tipoIVA;
        byte[] data = facturaString.getBytes();

        // Enviar datos al servidor
        DatagramPacket packet = new DatagramPacket(data, data.length,
                                                   InetAddress.getByName(serverAddress), port);
        socket.send(packet);

        // Recibir factura procesada del servidor
        byte[] buffer = new byte[1024];
        DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
        socket.receive(responsePacket);

        // Convertir respuesta a String y mostrar
        String facturaProcesada = new String(responsePacket.getData(), 0, responsePacket.getLength());
        System.out.println("\nFactura procesada recibida del servidor:");
        System.out.println(facturaProcesada);

        // Cerrar recursos
        scanner.close();
        socket.close();
    }
}
