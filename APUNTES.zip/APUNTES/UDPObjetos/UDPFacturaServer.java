import java.io.*;
import java.net.*;

public class UDPFacturaServer {
    public static void main(String[] args) throws IOException {
        int port = 6000;
        DatagramSocket socket = new DatagramSocket(port);
        System.out.println("Servidor UDP esperando conexión en el puerto " + port);

        while (true) {
            // Recibir datos del cliente
            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);

            // Convertir los datos recibidos a String
            String facturaString = new String(packet.getData(), 0, packet.getLength());
            System.out.println("\nFactura recibida: " + facturaString);

            // Procesar los datos
            String[] datos = facturaString.split(",");
            String numeroFactura = datos[0];
            String fecha = datos[1];
            double importe = Double.parseDouble(datos[2]);
            String tipoIVA = datos[3];

            // Calcular IVA
            double iva = calcularIVA(importe, tipoIVA);
            double total = importe + iva;

            // Crear respuesta con IVA calculado
            String facturaProcesada = numeroFactura + "," + fecha + "," + importe + "," + tipoIVA + "," + iva + "," + total;

            // Enviar respuesta al cliente
            byte[] responseData = facturaProcesada.getBytes();
            DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length,
                                                               packet.getAddress(), packet.getPort());
            socket.send(responsePacket);
            System.out.println("Factura procesada enviada al cliente: " + facturaProcesada);
        }
    }

    // Método para calcular IVA según el tipo
   public static double calcularIVA(double importe, String tipoIVA) {
    double porcentajeIVA;
    switch (tipoIVA.toUpperCase()) {
        case "IGC":
            porcentajeIVA = 0.05;
            break;
        case "ESP":
            porcentajeIVA = 0.10;
            break;
        case "EUR":
            porcentajeIVA = 0.21;
            break;
        default:
            porcentajeIVA = 0.0;
            break;
    }
    return importe * porcentajeIVA;
}
}
