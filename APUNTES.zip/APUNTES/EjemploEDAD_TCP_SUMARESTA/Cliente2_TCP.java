import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente2_TCP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 6667;

        try (Socket cliente = new Socket(host, puerto);
             ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
             ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());
             Scanner scanner = new Scanner(System.in)) {

            // Recibir objeto del servidor
            System.out.println("[Cliente 2] Esperando recibir objeto...");
            Persona persona = (Persona) in.readObject();
            System.out.println("[Cliente 2] Objeto recibido: " + persona);

            // Preguntar al usuario si desea sumar o restar
            System.out.println("[Cliente 2] ¿Qué desea hacer con la edad?");
            System.out.println("1. Sumar 5 años");
            System.out.println("2. Restar 5 años");
            int opcion;
            do {
                System.out.print("Ingrese opción (1 o 2): ");
                opcion = scanner.nextInt();
            } while (opcion != 1 && opcion != 2);

            // Modificar el objeto según la opción elegida
            boolean sumar = (opcion == 1);
            persona.modificarEdad(sumar);
            System.out.println("[Cliente 2] Objeto modificado: " + persona);

            // Enviar objeto modificado de vuelta al servidor
            System.out.println("[Cliente 2] Enviando objeto modificado al servidor...");
            out.writeObject(persona);
            out.flush();
            System.out.println("[Cliente 2] Objeto enviado.");

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
