import java.io.*;
import java.net.*;

public class UDPServidor {
    public static void main(String[] args) {
        int puertoCliente1 = 5000;
        int puertoCliente2 = 5001;
        
        try (DatagramSocket socket = new DatagramSocket(puertoCliente1)) {
            System.out.println("Servidor iniciado y esperando datos de Cliente 1...");

            // Recibir objeto de Cliente 1
            byte[] buffer = new byte[1024];
            DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
            socket.receive(paquete);

            // Obtener dirección y puerto de Cliente 1
            InetAddress direccionCliente1 = paquete.getAddress();
            int puertoCliente1Origen = paquete.getPort();

            // Reenviar objeto a Cliente 2
            try (DatagramSocket socket2 = new DatagramSocket()) {
                DatagramPacket paqueteACliente2 = new DatagramPacket(buffer, paquete.getLength(),
                                                                     direccionCliente1, puertoCliente2);
                socket2.send(paqueteACliente2);
                System.out.println("Objeto Persona enviado a Cliente 2...");
            }

            // Recibir objeto modificado de Cliente 2
            DatagramPacket paqueteProcesado = new DatagramPacket(buffer, buffer.length);
            socket.receive(paqueteProcesado);

            // Enviar de vuelta a Cliente 1
            DatagramPacket paqueteFinal = new DatagramPacket(paqueteProcesado.getData(), paqueteProcesado.getLength(),
                                                             direccionCliente1, puertoCliente1Origen);
            socket.send(paqueteFinal);
            System.out.println("Objeto modificado enviado a Cliente 1...");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
