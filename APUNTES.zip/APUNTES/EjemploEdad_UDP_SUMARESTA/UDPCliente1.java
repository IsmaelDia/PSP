import java.io.*;
import java.net.*;
import java.util.Scanner;

public class UDPCliente1 {
    public static void main(String[] args) {
        String servidor = "localhost";
        int puertoServidor = 5000;
        
        try (DatagramSocket socket = new DatagramSocket();
             Scanner scanner = new Scanner(System.in)) {
            
            // Pedir datos de la persona
            System.out.print("Ingrese su nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Ingrese su edad: ");
            int edad = scanner.nextInt();

            // Crear objeto Persona
            Persona persona = new Persona(nombre, edad);

            // Serializar el objeto
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(persona);
            byte[] datos = baos.toByteArray();

            // Enviar objeto al servidor
            DatagramPacket paquete = new DatagramPacket(datos, datos.length,
                                                        InetAddress.getByName(servidor), puertoServidor);
            socket.send(paquete);
            System.out.println("Objeto Persona enviado al servidor...");

            // Recibir respuesta procesada
            byte[] bufferRespuesta = new byte[1024];
            DatagramPacket paqueteRespuesta = new DatagramPacket(bufferRespuesta, bufferRespuesta.length);
            socket.receive(paqueteRespuesta);

            // Deserializar respuesta
            ByteArrayInputStream bais = new ByteArrayInputStream(paqueteRespuesta.getData());
            ObjectInputStream ois = new ObjectInputStream(bais);
            Persona personaProcesada = (Persona) ois.readObject();
            System.out.println("Persona procesada recibida del servidor: " + personaProcesada);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
