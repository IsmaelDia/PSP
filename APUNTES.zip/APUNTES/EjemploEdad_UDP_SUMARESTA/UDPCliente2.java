import java.io.*;
import java.net.*;
import java.util.Scanner;

public class UDPCliente2 {
    public static void main(String[] args) {
        int puertoServidor = 5001;
        
        try (DatagramSocket socket = new DatagramSocket(puertoServidor);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Esperando objeto del servidor...");

            // Recibir datos del servidor
            byte[] buffer = new byte[1024];
            DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
            socket.receive(paquete);

            // Deserializar objeto recibido
            ByteArrayInputStream bais = new ByteArrayInputStream(paquete.getData());
            ObjectInputStream ois = new ObjectInputStream(bais);
            Persona persona = (Persona) ois.readObject();

            // Mostrar datos y preguntar qué hacer
            System.out.println("Datos recibidos: " + persona);
            System.out.print("Ingrese 1 para sumar 5 años o 2 para restar 5 años: ");
            int opcion = scanner.nextInt();

            // Modificar edad según opción
            if (opcion == 1) {
                persona.sumarEdad(5);
            } else if (opcion == 2) {
                persona.restarEdad(5);
            }

            // Serializar objeto modificado
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(persona);
            byte[] datosModificados = baos.toByteArray();

            // Enviar objeto modificado al servidor
            DatagramPacket paqueteRespuesta = new DatagramPacket(datosModificados, datosModificados.length,
                                                                 paquete.getAddress(), 5000);
            socket.send(paqueteRespuesta);
            System.out.println("Objeto modificado enviado al servidor...");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
