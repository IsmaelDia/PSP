import java.io.*;
import java.net.*;

public class Cliente2_TCP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 6667;

        try (Socket cliente = new Socket(host, puerto);
             ObjectInputStream in = new ObjectInputStream(cliente.getInputStream());
             ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream())) {

            // Recibir objeto del servidor
            System.out.println("[Cliente 2] Esperando recibir objeto...");
            Persona persona = (Persona) in.readObject();
            System.out.println("[Cliente 2] Objeto recibido: " + persona);

            // Modificar el objeto (ejemplo: aumentar edad)
            persona.envejecer();
            System.out.println("[Cliente 2] Objeto modificado: " + persona);

            // Enviar objeto modificado de vuelta al servidor
            System.out.println("[Cliente 2] Enviando objeto modificado al servidor...");
            out.writeObject(persona);
            out.flush();
            System.out.println("[Cliente 2] Objeto enviado.");

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
