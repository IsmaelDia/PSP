import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente1_TCP {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 6666;

        try (Socket cliente = new Socket(host, puerto);
             ObjectOutputStream out = new ObjectOutputStream(cliente.getOutputStream());
             Scanner scanner = new Scanner(System.in)) {

            // Solicitar datos al usuario
            System.out.print("Ingrese nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Ingrese edad: ");
            int edad = scanner.nextInt();

            // Crear objeto y enviarlo al servidor
            Persona persona = new Persona(nombre, edad);
            out.writeObject(persona);
            out.flush();
            System.out.println("Objeto enviado al Servidor: " + persona);

            // Esperar el objeto modificado
            try (Socket cliente2 = new Socket(host, puerto);
                 ObjectInputStream in = new ObjectInputStream(cliente2.getInputStream())) {
                Persona personaModificada = (Persona) in.readObject();
                System.out.println("Objeto modificado recibido: " + personaModificada);
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
