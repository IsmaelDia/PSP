import java.io.*;
import java.net.*;

public class ServidorTCP {
    public static void main(String[] args) {
        int puerto1 = 6666, puerto2 = 6667;

        try (ServerSocket server1 = new ServerSocket(puerto1);
             ServerSocket server2 = new ServerSocket(puerto2)) {
            
            System.out.println("Servidor iniciado. Esperando conexiones...");

            // Recibir objeto de Cliente1
            Socket cliente1 = server1.accept();
            ObjectInputStream in1 = new ObjectInputStream(cliente1.getInputStream());
            Persona persona = (Persona) in1.readObject();
            System.out.println("Servidor recibió de Cliente 1: " + persona);
            cliente1.close();

            // Enviar objeto a Cliente2
            Socket cliente2 = server2.accept();
            ObjectOutputStream out2 = new ObjectOutputStream(cliente2.getOutputStream());
            out2.writeObject(persona);
            out2.flush();

            // Recibir objeto modificado de Cliente2
            ObjectInputStream in2 = new ObjectInputStream(cliente2.getInputStream());
            Persona personaModificada = (Persona) in2.readObject();
            System.out.println("Servidor recibió de Cliente 2 (modificado): " + personaModificada);
            cliente2.close();

            // Enviar objeto modificado a Cliente1
            cliente1 = server1.accept();
            ObjectOutputStream out1 = new ObjectOutputStream(cliente1.getOutputStream());
            out1.writeObject(personaModificada);
            out1.flush();
            System.out.println("Objeto modificado enviado a Cliente 1.");
            cliente1.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
