package EjerSockets4TCP;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente1 {

    public static void main(String[] args) throws IOException {
        try {
            Scanner entrada = new Scanner(System.in);
            int numero;

            String host = "localhost";
            int numeroPuerto = 5005; // Puerto del servidor

            // Crear el socket para conectarse al servidor
            Socket cliente1 = new Socket(host, numeroPuerto);

            DataOutputStream out = new DataOutputStream(cliente1.getOutputStream());

            while (true) 
            {
                System.out.println("Introduce un número:");
                numero = entrada.nextInt();

                // Enviar el número al servidor
                out.writeInt(numero);
                out.flush();

                // Esperar a que el servidor responda
                // Aquí podrías implementar la lógica para recibir la respuesta del servidor si fuera necesario

                // Salir del bucle si se adivinó el número
                if (adivinoNumero()) 
                {
                    System.out.println("¡Has adivinado el número!");
                    break;
                }
            }

            // Cerrar la conexión con el servidor
            cliente1.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método de ejemplo para determinar si se adivinó el número
    public static boolean adivinoNumero() 
    {
        // Aquí podrías implementar la lógica para recibir la respuesta del servidor
        // y determinar si el número fue adivinado
        return false; // Por ahora, siempre retornamos false para continuar ingresando números
    }
}
