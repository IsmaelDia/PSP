package EjerSockets3TCP;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        int puerto = 5001; // Puerto en el que el servidor escucha

        System.out.println("Socket servidor");
        ServerSocket servidor = new ServerSocket(puerto);

        while (true) {
            Socket cliente = servidor.accept(); // Espera a que un cliente se conecte

            ObjectInputStream facturaEntrada = new ObjectInputStream(cliente.getInputStream());
            Factura factura = (Factura) facturaEntrada.readObject(); // Recibe el objeto Factura del cliente

            int importe = factura.getImporte();
            String tipoIVA = factura.getTipoIVA();
            double importeTotal = 0;
            int iva = 0;

            if (tipoIVA.equals("ESP")) 
            {
                iva = (int) (0.21 * importe);
                importeTotal = iva + importe;
            } 
            else if (tipoIVA.equals("IGC")) 
            {
                iva = (int) (0.07 * importe);
                importeTotal = iva + importe;
            } else if (tipoIVA.equals("EUR")) 
            {
                iva = (int) (0.15 * importe);
                importeTotal = iva + importe;
            }
            else
            {
                    System.out.println("Tienes que elegir un tipo de IVA");    
            }

            factura.setIVA(iva);
            factura.setImporteTotal(importeTotal);

            ObjectOutputStream facturaSalida = new ObjectOutputStream(cliente.getOutputStream());
            facturaSalida.writeObject(factura); // Envía la factura modificada al cliente

            // Cierra los streams y el socket del cliente
            facturaEntrada.close();
            facturaSalida.close();
            cliente.close();
        }
    }
}
