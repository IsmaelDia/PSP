import java.io.*;
import java.net.*;

public class SocketClientBolsaUDP {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {

            InetAddress serverAddress = InetAddress.getByName("localhost");
            int serverPort = 22345;

            while (true) {
                // Enviar código de acción al servidor
                System.out.print("Código de acción bursátil: ");
                String codigoAccion = reader.readLine();
                byte[] codigoBytes = codigoAccion.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(codigoBytes, codigoBytes.length, serverAddress, serverPort);
                socket.send(sendPacket);

                // Preguntar qué información quiere el usuario
                boolean continuar = true;
                while (continuar) {
                    System.out.print("que informacion quieres conocer (1 = ValorActual | 2 = ValorMinimo | 3 = ValorMaximo | 4 = salir)");
                    String opcion = reader.readLine();
                    byte[] opcionBytes = opcion.getBytes();
                    DatagramPacket opcionPacket = new DatagramPacket(opcionBytes, opcionBytes.length, serverAddress, serverPort);
                    socket.send(opcionPacket);

                    if (opcion.equals("4")) {
                        continuar = false;
                        return;//para salir del bucle de preguntar info
                    }

                    // Recibir respuesta del servidor
                    byte[] buffer = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                    socket.receive(receivePacket);
                    String respuesta = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("Servidor: " + respuesta);
                }
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
