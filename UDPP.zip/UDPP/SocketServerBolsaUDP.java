import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class SocketServerBolsaUDP {
    public static void main(String[] args) {
        ArrayList<AccionBolsa> listaAcciones = new ArrayList<>();
        listaAcciones.add(new AccionBolsa("Banco Bilbao Vizcaya", "BBVA", 9.286, 9.110, 9.296));
        listaAcciones.add(new AccionBolsa("Banco Santander", "SANT", 3.824, 3.782, 3.849));
        listaAcciones.add(new AccionBolsa("Iberdrola", "IBER", 10.965, 10.855, 10.980));
        listaAcciones.add(new AccionBolsa("Repsol", "REPS", 13.620, 13.480, 13.670));

        try (DatagramSocket socket = new DatagramSocket(22345)) {
            System.out.println("Servidor UDP Bolsa preparado...");

            byte[] buffer = new byte[1024];

            while (true) {
                // Recibir código de acción del cliente
                DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
                socket.receive(receivePacket);
                String codigoAccion = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
                System.out.println("Código recibido: " + codigoAccion);

                AccionBolsa accion = buscarAccion(listaAcciones, codigoAccion);

                if (accion != null) {
                    boolean continuar = true;
                    while (continuar) {
                        //recibe el numero que diga el cliente
                        socket.receive(receivePacket);
                        String opcionStr = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
                        int opcion = Integer.parseInt(opcionStr);

                        String respuesta = "";
                        switch (opcion) {
                            case 1:
                                respuesta = "Valor Actual: " + accion.getValorActual();
                                break;
                            case 2:
                                respuesta = "Valor Minimo: " + accion.getValorMinimo();
                                break;
                            case 3:
                                respuesta = "Valor Maximo: " + accion.getValorMaximo();
                                break;
                            case 4:
                                continuar = false;
                                return; //sale del bucle y cierra el server
                                //puedo usar 'continue' y solamente sale del bucle pero no cierra el server
                            default:
                                respuesta = "error:selecciona un numero del 1 al 4";
                        }

                        //envio la respuesta al cliente
                        byte[] responseBytes = respuesta.getBytes();
                        DatagramPacket sendPacket = new DatagramPacket(responseBytes, responseBytes.length,
                                receivePacket.getAddress(), receivePacket.getPort());
                        socket.send(sendPacket);
                    }
                } else {
                    String mjsERROR = "ese codigo no esta en la base de datos";
                    byte[] errorBytes = mjsERROR.getBytes();
                    DatagramPacket errorPacket = new DatagramPacket(errorBytes, errorBytes.length,//enviar el mensaje de error
                            receivePacket.getAddress(), receivePacket.getPort());
                    socket.send(errorPacket);//lo mando
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static AccionBolsa buscarAccion(ArrayList<AccionBolsa> acciones, String codigo) {
        for (AccionBolsa accion : acciones) {
            if (accion.getCodigoAccion().equals(codigo)) {
                return accion;
            }
        }
        return null;
    }
}

